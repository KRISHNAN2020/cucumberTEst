package StepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class LoginStepDefinition {
    WebDriver driver;

    @Given("User is in Credentials page")
    public void userIsInCredentialsPage() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver() ;
        driver.get("https://aggqa.alldata.cashedge.com/PFM_UI/login/88886648");
    }

    @When("Credentials are entered and submit button is clicked")
    public void credentialsAreEnteredAndSubmitButtonIsClicked() {
        WebElement username = driver.findElement(By.id("j_idt45:j_idt71:0:login_"));
        username.sendKeys("browsertest");
        WebElement password =  driver.findElement(By.id("j_idt45:j_idt76:0:password_"));
        password.sendKeys("browsertest");
        WebElement signin =  driver.findElement(By.id("j_idt45:j_idt83"));
        signin.click();
    }

    @Then("Dashboard Page should be launched successfully")
    public void dashboardPageShouldBeLaunchedSuccessfully() {
        WebElement DashboardTitle = driver.findElement(By.xpath("//*[@id=\"nav_main\"]/li[1]/a"));
        String DashboardText = DashboardTitle.getText();
        Assert.assertEquals(DashboardText,"DASHBOARD");
    }
}
